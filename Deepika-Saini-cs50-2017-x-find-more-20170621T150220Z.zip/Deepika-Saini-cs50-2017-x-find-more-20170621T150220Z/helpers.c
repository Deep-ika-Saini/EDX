/**
 * helpers.c
 *
 * Helper functions for Problem Set 3.
 */
 
#include <cs50.h>
#include "helpers.h"

bool binary(int value, int values[], int l, int r)
{
    if(r>=l)
    {
        int m = (l+r)/2;
        if(values[m] == value)
            return true;
        else
        {
            if(values[m] > value)
                return binary(value, values, l, m-1);
            else
                return binary(value, values, m+1, r);
        }
    }
    return false;
}

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    if(n < 0)
        return false;
    else
    {
        bool b = binary(value, values, 0, n);
        if(b == true)
            return true;
        else
            return false;
    }
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    int temp[65536] = {0};
    
    for(int i = 0; i < n; i++)
    {
        temp[values[i]]++;
    }
    for(int i = 0, j = 0; i < 65536; i++)
    {
        while(temp[i] != 0)
        {
            values[j++] = i;
            temp[i]--;
        }
    }
    return;
}
